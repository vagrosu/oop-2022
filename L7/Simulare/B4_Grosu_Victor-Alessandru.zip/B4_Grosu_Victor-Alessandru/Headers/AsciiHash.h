#include "Hash.h"

class CountAsciiHash : public Hash {
    int calculateHash(char *) override;
};

