#include "Hash.h"

class CountConsonantHash : public Hash {
    int calculateHash(char *) override;
};
