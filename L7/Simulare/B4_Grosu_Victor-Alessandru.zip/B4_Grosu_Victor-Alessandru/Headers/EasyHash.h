#include "Hash.h"

class EasyHash : public Hash {
    int calculateHash(char *) override;
};