class Hash {
    virtual int calculateHash(char *);
};
