#include "Hash.h"

class HashManager {
    int hashesNumber;
    Hash *hashes[];
public:
    HashManager();
    void print_hashes(char *);
};
