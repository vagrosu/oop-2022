#include "Hash.h"

class CountVowelsHash : public Hash {
    int calculateHash(char *) override;
};
