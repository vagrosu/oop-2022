#include "Headers/HashManager.h"

HashManager::HashManager() {
    this->hashesNumber = 0;
}

void HashManager::print_hashes(char *) {

}
